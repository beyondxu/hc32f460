./output/debug/hc32_ll_utility.o: \
  ..\..\..\..\..\..\drivers\hc32_ll_driver\src\hc32_ll_utility.c \
  ..\..\..\..\..\..\drivers\hc32_ll_driver\inc\hc32_ll_utility.h \
  ..\..\..\..\..\..\drivers\hc32_ll_driver\inc\hc32_ll_def.h \
  E:\Keil_v5\ARM\ARMCLANG\Bin\..\include\stddef.h \
  E:\Keil_v5\ARM\ARMCLANG\Bin\..\include\stdint.h \
  ..\..\..\..\..\..\drivers\cmsis\Device\HDSC\hc32f4xx\Include\hc32f4xx.h \
  ..\..\..\..\..\..\drivers\cmsis\Device\HDSC\hc32f4xx\Include\hc32f460.h \
  ..\..\..\..\..\..\drivers\cmsis\Include\core_cm4.h \
  ..\..\..\..\..\..\drivers\cmsis\Include\cmsis_version.h \
  ..\..\..\..\..\..\drivers\cmsis\Include\cmsis_compiler.h \
  ..\..\..\..\..\..\drivers\cmsis\Include\cmsis_armclang.h \
  E:\Keil_v5\ARM\ARMCLANG\Bin\..\include\arm_compat.h \
  E:\Keil_v5\ARM\ARMCLANG\Bin\..\include\arm_acle.h \
  ..\..\..\..\..\..\drivers\cmsis\Include\mpu_armv7.h \
  ..\..\..\..\..\..\drivers\cmsis\Device\HDSC\hc32f4xx\Include\system_hc32f460.h \
  ..\source\hc32f4xx_conf.h \
  E:\Keil_v5\ARM\ARMCLANG\Bin\..\include\stdio.h
