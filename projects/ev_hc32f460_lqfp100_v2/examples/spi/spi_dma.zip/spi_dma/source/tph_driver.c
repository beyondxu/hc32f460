#include "tph_driver.h"

// ----------------------------------------------------------------------------
// M0333N ����� 3.2 �� Table ��ַӳ����� (Add1 ~ Add25)
// ----------------------------------------------------------------------------
static const uint8_t TPH_ADDR_CODE[25] = {
    0x07, 0x0B, 0x13, 0x0D, 0x15, 0x19, 0x0E, 0x16, 0x26, 0x1A,
    0x2A, 0x32, 0x1C, 0x2C, 0x4C, 0x34, 0x54, 0x64, 0x38, 0x58,
    0x68, 0x70, 0x23, 0x43, 0x25
};

// ----------------------------------------------------------------------------
// ΢�뼰���뼶��ʱ���� (ϵͳ��Ƶ 200MHz: 1���� = 5ns)
// ----------------------------------------------------------------------------
// ��������ʱ�� ts >= 0.38us (�͵�ƽ����ʱ��)
static inline void TPH_DelayTs(void) {
    for (volatile uint32_t i = 0UL; i < 20UL; i++) {
        __NOP();
    }
}

// �Ͽ������ʱ�� tFire: 2.0us ~ 2.2us
static inline void TPH_DelayTfire(void) {
    for (volatile uint32_t i = 0UL; i < 92UL; i++) {
        __NOP();
    }
}

// ͨ��΢����ʱ (�������µ�ʱ��)
static void TPH_DelayUS(uint32_t us) {
    for (volatile uint32_t i = 0UL; i < us * 40UL; i++) {
        __NOP();
    }
}

// ----------------------------------------------------------------------------
// �������� A1 ~ A7 �����е�ַ (ȫ�� Port B)
// A1:PB2, A2:PB10, A3:PB1, A4:PB12, A5:PB14, A6:PB13, A7:PB0
// ----------------------------------------------------------------------------
static inline void TPH_SetAddressFast(uint8_t u8AddrCode) {
    uint16_t u16SetMask = 0U;
    uint16_t u16ClrMask = 0U;

    if (u8AddrCode & 0x01U) u16SetMask |= GPIO_PIN_02; else u16ClrMask |= GPIO_PIN_02; // A1
    if (u8AddrCode & 0x02U) u16SetMask |= GPIO_PIN_10; else u16ClrMask |= GPIO_PIN_10; // A2
    if (u8AddrCode & 0x04U) u16SetMask |= GPIO_PIN_01; else u16ClrMask |= GPIO_PIN_01; // A3
    if (u8AddrCode & 0x08U) u16SetMask |= GPIO_PIN_12; else u16ClrMask |= GPIO_PIN_12; // A4
    if (u8AddrCode & 0x10U) u16SetMask |= GPIO_PIN_14; else u16ClrMask |= GPIO_PIN_14; // A5
    if (u8AddrCode & 0x20U) u16SetMask |= GPIO_PIN_13; else u16ClrMask |= GPIO_PIN_13; // A6
    if (u8AddrCode & 0x40U) u16SetMask |= GPIO_PIN_00; else u16ClrMask |= GPIO_PIN_00; // A7

    GPIO_ResetPins(GPIO_PORT_B, u16ClrMask);
    GPIO_SetPins(GPIO_PORT_B, u16SetMask);
}

// ----------------------------------------------------------------------------
// ������� D1 ~ D6 ���� (ȫ�� Port A)
// D1:PA0, D2:PA2, D3:PA1, D4:PA10, D5:PA8, D6:PA3
// ----------------------------------------------------------------------------
static inline void TPH_SetDataFast(uint8_t u8Data6Bit) {
    uint16_t u16SetMask = 0U;
    uint16_t u16ClrMask = 0U;

    if (u8Data6Bit & 0x01U) u16SetMask |= GPIO_PIN_00; else u16ClrMask |= GPIO_PIN_00; // D1
    if (u8Data6Bit & 0x02U) u16SetMask |= GPIO_PIN_02; else u16ClrMask |= GPIO_PIN_02; // D2
    if (u8Data6Bit & 0x04U) u16SetMask |= GPIO_PIN_01; else u16ClrMask |= GPIO_PIN_01; // D3
    if (u8Data6Bit & 0x08U) u16SetMask |= GPIO_PIN_10; else u16ClrMask |= GPIO_PIN_10; // D4
    if (u8Data6Bit & 0x10U) u16SetMask |= GPIO_PIN_08; else u16ClrMask |= GPIO_PIN_08; // D5
    if (u8Data6Bit & 0x20U) u16SetMask |= GPIO_PIN_03; else u16ClrMask |= GPIO_PIN_03; // D6

    GPIO_ResetPins(GPIO_PORT_A, u16ClrMask);
    GPIO_SetPins(GPIO_PORT_A, u16SetMask);
}

// ----------------------------------------------------------------------------
// ��ͷ���ų�ʼ������
// ----------------------------------------------------------------------------
void TPH_Init(void) {
    stc_gpio_init_t stcGpioInit;

    (void)GPIO_StructInit(&stcGpioInit);
    stcGpioInit.u16PinDir        = PIN_DIR_OUT;
    stcGpioInit.u16PinDrv        = PIN_HIGH_DRV; // ���ٶ��ͱ��أ���Сʱ�Ӷ���
    stcGpioInit.u16PinOutputType = PIN_OUT_TYPE_CMOS;
    stcGpioInit.u16PinState      = PIN_STAT_RST;

    // 1. ��ʼ����Դʹ�ܼ� CE ����
    (void)GPIO_Init(TPH_PWR_VP_PORT, TPH_PWR_VP_PIN, &stcGpioInit);
    (void)GPIO_Init(TPH_PWR_VL_PORT, TPH_PWR_VL_PIN, &stcGpioInit);
    (void)GPIO_Init(TPH_CE_PORT,     TPH_CE_PIN,     &stcGpioInit);

    // 2. ��ʼ�� A1~A7 ��ַ���� (Port B)
    (void)GPIO_Init(GPIO_PORT_B, GPIO_PIN_00 | GPIO_PIN_01 | GPIO_PIN_02 | GPIO_PIN_10 |
                                 GPIO_PIN_12 | GPIO_PIN_13 | GPIO_PIN_14, &stcGpioInit);

    // 3. ��ʼ�� D1~D6 �������� (Port A)
    (void)GPIO_Init(GPIO_PORT_A, GPIO_PIN_00 | GPIO_PIN_01 | GPIO_PIN_02 | GPIO_PIN_03 |
                                 GPIO_PIN_08 | GPIO_PIN_10, &stcGpioInit);

    // 4. ��ʼ�� S1~S4 �ֶ��������� (Ĭ�ϱ��뱣�� HIGH ����̬��)
    stcGpioInit.u16PinState = PIN_STAT_SET;
    (void)GPIO_Init(TPH_S1_PORT, TPH_S1_PIN, &stcGpioInit);
    (void)GPIO_Init(TPH_S2_PORT, TPH_S2_PIN, &stcGpioInit);
    (void)GPIO_Init(TPH_S3_PORT, TPH_S3_PIN, &stcGpioInit);
    (void)GPIO_Init(TPH_S4_PORT, TPH_S4_PIN, &stcGpioInit);

    // 5. �� BK7258 ��ͬ���ź���
    // BK_1 (PC13): ���룬������
    stcGpioInit.u16PinDir   = PIN_DIR_IN;
    stcGpioInit.u16PullUp   = PIN_PU_ON;
    (void)GPIO_Init(TPH_SYNC_IN_PORT, TPH_SYNC_IN_PIN, &stcGpioInit);

    // BK_2 (PH2): �����Ĭ�ϵ͵�ƽ
    stcGpioInit.u16PinDir   = PIN_DIR_OUT;
    stcGpioInit.u16PinState = PIN_STAT_RST;
    (void)GPIO_Init(TPH_READY_OUT_PORT, TPH_READY_OUT_PIN, &stcGpioInit);
}

// ----------------------------------------------------------------------------
// �Ͽ���Դ���µ�˳�򱣻� (���Ϲ���� 3.3 ʱ��)
// ----------------------------------------------------------------------------
void TPH_PowerControl(en_functional_state_t enState) {
    if (ENABLE == enState) {
        // �ϵ�˳���ȿ��� VL(�߼�15V) -> �ȴ� tpo >= 5us -> �ٿ��� VP(����15V)
        GPIO_SetPins(TPH_PWR_VL_PORT, TPH_PWR_VL_PIN);
        TPH_DelayUS(10U); // tpo >= 5us
        GPIO_SetPins(TPH_PWR_VP_PORT, TPH_PWR_VP_PIN);
        TPH_DelayUS(50U); // ��ѹ��ʱ
    } else {
        // �µ�˳��CE ������ -> �ض� VP -> �ȴ� tpf >= 5us -> �ض� VL
        GPIO_ResetPins(TPH_CE_PORT,     TPH_CE_PIN);
        GPIO_ResetPins(TPH_PWR_VP_PORT, TPH_PWR_VP_PIN);
        TPH_DelayUS(10U); // tpf >= 5us
        GPIO_ResetPins(TPH_PWR_VL_PORT, TPH_PWR_VL_PIN);
    }
}

// ----------------------------------------------------------------------------
// ���Ĵ����������һ�е��� (25 Addr x 4 Section = 100 �ֽ�ѭ��)
// ----------------------------------------------------------------------------
void TPH_FireOneColumn(const uint8_t *pu8Data) {
    uint32_t u32Offset = 0UL;

    for (uint8_t add_idx = 0U; add_idx < TPH_ADDR_NUM; add_idx++) {
        // 1. ���������е�ַ A1~A7
        TPH_SetAddressFast(TPH_ADDR_CODE[add_idx]);
        TPH_DelayTs();

        // 2. ���μ������� S1 ~ S4 ���� (�͵�ƽ�������ߵ�ƽ����)
        // S1
        TPH_SetDataFast(pu8Data[u32Offset++]);
        GPIO_ResetPins(TPH_S1_PORT, TPH_S1_PIN); // S1 = 0 (����)
        TPH_DelayTs();
        GPIO_SetPins(TPH_S1_PORT, TPH_S1_PIN);   // S1 = 1 (����)

        // S2
        TPH_SetDataFast(pu8Data[u32Offset++]);
        GPIO_ResetPins(TPH_S2_PORT, TPH_S2_PIN); // S2 = 0
        TPH_DelayTs();
        GPIO_SetPins(TPH_S2_PORT, TPH_S2_PIN);   // S2 = 1

        // S3
        TPH_SetDataFast(pu8Data[u32Offset++]);
        GPIO_ResetPins(TPH_S3_PORT, TPH_S3_PIN); // S3 = 0
        TPH_DelayTs();
        GPIO_SetPins(TPH_S3_PORT, TPH_S3_PIN);   // S3 = 1

        // S4
        TPH_SetDataFast(pu8Data[u32Offset++]);
        GPIO_ResetPins(TPH_S4_PORT, TPH_S4_PIN); // S4 = 0
        TPH_DelayTs();
        GPIO_SetPins(TPH_S4_PORT, TPH_S4_PIN);   // S4 = 1

        // 3. ���Ĵ��ʹ������ (����ʱ���Ͽ��� 2.0us ~ 2.2us)
        GPIO_SetPins(TPH_CE_PORT, TPH_CE_PIN);   // CE = 1
        TPH_DelayTfire();                        // ��ȷά�� 2.0us
        GPIO_ResetPins(TPH_CE_PORT, TPH_CE_PIN); // CE = 0 (�����ض�)

        // īˮ����ȴ�
        TPH_DelayTs();
    }
}