#include "main.h"
#include "tph_driver.h"
#include <stdio.h>
#include <string.h>

#define EXAMPLE_PERIPH_WE   (LL_PERIPH_GPIO | LL_PERIPH_EFM | LL_PERIPH_FCG | \
                             LL_PERIPH_PWC_CLK_RMU | LL_PERIPH_SRAM)
#define EXAMPLE_PERIPH_WP   (LL_PERIPH_EFM | LL_PERIPH_FCG | LL_PERIPH_SRAM)

/* ? ???? 1:????? BK7258 ???? (256 ??) ? */
#define EXAMPLE_SPI_BUF_LEN (256UL)

/* ================= 1. J4 ???? ================= */
#define J4_UART_UNIT            (CM_USART2)
#define J4_UART_CLK             (FCG1_PERIPH_USART2)
#define J4_UART_TX_PORT         (GPIO_PORT_A)
#define J4_UART_TX_PIN          (GPIO_PIN_12)
#define J4_UART_TX_FUNC         (GPIO_FUNC_36)
#define J4_UART_RX_PORT         (GPIO_PORT_A)
#define J4_UART_RX_PIN          (GPIO_PIN_11)
#define J4_UART_RX_FUNC         (GPIO_FUNC_37)

/* ================= 2. ???? PH2 (BK_2 ??) ================= */
#define READY_PORT              (GPIO_PORT_H)
#define READY_PIN               (GPIO_PIN_02)

/* ================= 3. SPI1 ??????? ================= */
#define SPI_UNIT                (CM_SPI1)
#define SPI_CLK                 (FCG1_PERIPH_SPI1)
#define SPI_TX_EVT_SRC          (EVT_SRC_SPI1_SPTI)
#define SPI_RX_EVT_SRC          (EVT_SRC_SPI1_SPRI)

#define SPI_SS_PORT             (GPIO_PORT_A)
#define SPI_SS_PIN              (GPIO_PIN_04)
#define SPI_SS_FUNC             (GPIO_FUNC_42)  // NSS0

#define SPI_SCK_PORT            (GPIO_PORT_A)
#define SPI_SCK_PIN             (GPIO_PIN_05)
#define SPI_SCK_FUNC            (GPIO_FUNC_43)  // SCK

#define SPI_MOSI_PORT           (GPIO_PORT_A)
#define SPI_MOSI_PIN            (GPIO_PIN_06)
#define SPI_MOSI_FUNC           (GPIO_FUNC_40)  // MOSI

#define SPI_MISO_PORT           (GPIO_PORT_A)
#define SPI_MISO_PIN            (GPIO_PIN_07)
#define SPI_MISO_FUNC           (GPIO_FUNC_41)  // MISO

/* ================= 4. DMA ???? ================= */
#define DMA_UNIT                (CM_DMA1)
#define DMA_CLK                 (FCG0_PERIPH_DMA1 | FCG0_PERIPH_AOS)
#define DMA_TX_CH               (DMA_CH0)
#define DMA_TX_TRIG_CH          (AOS_DMA1_0)

#define DMA_RX_CH               (DMA_CH1)
#define DMA_RX_INT_CH           (DMA_INT_TC_CH1)
#define DMA_RX_TRIG_CH          (AOS_DMA1_1)
#define DMA_RX_INT_SRC          (INT_SRC_DMA1_TC1)
#define DMA_RX_IRQ_NUM          (INT006_IRQn)

static uint8_t u8TxBuf[EXAMPLE_SPI_BUF_LEN];
static uint8_t u8RxBuf[EXAMPLE_SPI_BUF_LEN];
static volatile en_flag_status_t enRxCompleteFlag = RESET;
static volatile uint32_t u32PacketIndex = 0;

static int32_t J4_UART_PreInit(void *vpDevice, uint32_t u32Baudrate) {
    stc_usart_uart_init_t stcUartInit;
    stc_gpio_init_t stcGpioInit;
    CM_USART_TypeDef *USARTx = (CM_USART_TypeDef *)vpDevice;

    FCG_Fcg1PeriphClockCmd(FCG1_PERIPH_USBFS, DISABLE);
    FCG_Fcg1PeriphClockCmd(J4_UART_CLK, ENABLE);

    (void)GPIO_StructInit(&stcGpioInit);
    stcGpioInit.u16PinDrv        = PIN_HIGH_DRV;
    stcGpioInit.u16PinDir        = PIN_DIR_OUT;
    stcGpioInit.u16PinOutputType = PIN_OUT_TYPE_CMOS;
    (void)GPIO_Init(J4_UART_TX_PORT, J4_UART_TX_PIN, &stcGpioInit);

    stcGpioInit.u16PinDrv        = PIN_LOW_DRV;
    stcGpioInit.u16PinDir        = PIN_DIR_IN;
    stcGpioInit.u16PullUp        = PIN_PU_ON;
    (void)GPIO_Init(J4_UART_RX_PORT, J4_UART_RX_PIN, &stcGpioInit);

    GPIO_SetFunc(J4_UART_TX_PORT, J4_UART_TX_PIN, J4_UART_TX_FUNC);
    GPIO_SetFunc(J4_UART_RX_PORT, J4_UART_RX_PIN, J4_UART_RX_FUNC);

    (void)USART_UART_StructInit(&stcUartInit);
    stcUartInit.u32ClockSrc          = USART_CLK_SRC_INTERNCLK;
    stcUartInit.u32ClockDiv          = USART_CLK_DIV1;
    stcUartInit.u32Baudrate          = u32Baudrate;
    stcUartInit.u32DataWidth         = USART_DATA_WIDTH_8BIT;
    stcUartInit.u32StopBit           = USART_STOPBIT_1BIT;
    stcUartInit.u32Parity            = USART_PARITY_NONE;
    stcUartInit.u32OverSampleBit     = USART_OVER_SAMPLE_16BIT;
    stcUartInit.u32FirstBit          = USART_FIRST_BIT_LSB;
    stcUartInit.u32HWFlowControl     = USART_HW_FLOWCTRL_RTS;
    (void)USART_UART_Init(USARTx, &stcUartInit, NULL);

    USART_FuncCmd(USARTx, (USART_TX | USART_RX), ENABLE);
    return LL_OK;
}

static void DMA_TransCompleteCallback(void) {
    enRxCompleteFlag = SET;
    DMA_ClearTransCompleteStatus(DMA_UNIT, DMA_RX_INT_CH);
}

static void Handshake_Pin_Init(void) {
    stc_gpio_init_t stcGpioInit;
    (void)GPIO_StructInit(&stcGpioInit);
    stcGpioInit.u16PinDir        = PIN_DIR_OUT;
    stcGpioInit.u16PinDrv        = PIN_HIGH_DRV;
    stcGpioInit.u16PinOutputType = PIN_OUT_TYPE_CMOS;
    stcGpioInit.u16PinState      = PIN_STAT_RST; // ????
    GPIO_Init(READY_PORT, READY_PIN, &stcGpioInit);
}

static void SPI_Config(void) {
    stc_spi_init_t stcSpiInit;
    stc_dma_init_t stcDmaInit;
    stc_irq_signin_config_t stcIrqSignConfig;
    stc_gpio_init_t stcGpioInit;

    (void)GPIO_StructInit(&stcGpioInit);
    stcGpioInit.u16PinDrv = PIN_HIGH_DRV;
    (void)GPIO_Init(SPI_SS_PORT,   SPI_SS_PIN,   &stcGpioInit);
    (void)GPIO_Init(SPI_SCK_PORT,  SPI_SCK_PIN,  &stcGpioInit);
    (void)GPIO_Init(SPI_MOSI_PORT, SPI_MOSI_PIN, &stcGpioInit);
    (void)GPIO_Init(SPI_MISO_PORT, SPI_MISO_PIN, &stcGpioInit);

    GPIO_SetFunc(SPI_SS_PORT,   SPI_SS_PIN,   SPI_SS_FUNC);
    GPIO_SetFunc(SPI_SCK_PORT,  SPI_SCK_PIN,  SPI_SCK_FUNC);
    GPIO_SetFunc(SPI_MOSI_PORT, SPI_MOSI_PIN, SPI_MOSI_FUNC);
    GPIO_SetFunc(SPI_MISO_PORT, SPI_MISO_PIN, SPI_MISO_FUNC);

    FCG_Fcg1PeriphClockCmd(SPI_CLK, ENABLE);
    SPI_StructInit(&stcSpiInit);
    stcSpiInit.u32WireMode          = SPI_4_WIRE;
    stcSpiInit.u32TransMode         = SPI_FULL_DUPLEX;
    stcSpiInit.u32MasterSlave       = SPI_SLAVE;
    stcSpiInit.u32Parity            = SPI_PARITY_INVD;
    stcSpiInit.u32SpiMode           = SPI_MD_3; // ? BK7258 Mode 3 (CPOL=1, CPHA=1) ????
    stcSpiInit.u32BaudRatePrescaler = SPI_BR_CLK_DIV64;
    stcSpiInit.u32DataBits          = SPI_DATA_SIZE_8BIT;
    stcSpiInit.u32FirstBit          = SPI_FIRST_MSB;
    stcSpiInit.u32FrameLevel        = SPI_1_FRAME;
    (void)SPI_Init(SPI_UNIT, &stcSpiInit);

    FCG_Fcg0PeriphClockCmd(DMA_CLK, ENABLE);
    (void)DMA_StructInit(&stcDmaInit);
    stcDmaInit.u32BlockSize  = 1UL;
    stcDmaInit.u32TransCount = EXAMPLE_SPI_BUF_LEN;
    stcDmaInit.u32DataWidth  = DMA_DATAWIDTH_8BIT;

    // DMA TX
    stcDmaInit.u32SrcAddrInc  = DMA_SRC_ADDR_INC;
    stcDmaInit.u32DestAddrInc = DMA_DEST_ADDR_FIX;
    stcDmaInit.u32SrcAddr     = (uint32_t)(&u8TxBuf[0]);
    stcDmaInit.u32DestAddr    = (uint32_t)(&SPI_UNIT->DR);
    (void)DMA_Init(DMA_UNIT, DMA_TX_CH, &stcDmaInit);
    AOS_SetTriggerEventSrc(DMA_TX_TRIG_CH, SPI_TX_EVT_SRC);

    // DMA RX
    stcDmaInit.u32IntEn       = DMA_INT_ENABLE;
    stcDmaInit.u32SrcAddrInc  = DMA_SRC_ADDR_FIX;
    stcDmaInit.u32DestAddrInc = DMA_DEST_ADDR_INC;
    stcDmaInit.u32SrcAddr     = (uint32_t)(&SPI_UNIT->DR);
    stcDmaInit.u32DestAddr    = (uint32_t)(&u8RxBuf[0]);
    (void)DMA_Init(DMA_UNIT, DMA_RX_CH, &stcDmaInit);
    AOS_SetTriggerEventSrc(DMA_RX_TRIG_CH, SPI_RX_EVT_SRC);

    stcIrqSignConfig.enIntSrc    = DMA_RX_INT_SRC;
    stcIrqSignConfig.enIRQn      = DMA_RX_IRQ_NUM;
    stcIrqSignConfig.pfnCallback = &DMA_TransCompleteCallback;
    (void)INTC_IrqSignIn(&stcIrqSignConfig);
    NVIC_ClearPendingIRQ(stcIrqSignConfig.enIRQn);
    NVIC_SetPriority(stcIrqSignConfig.enIRQn, DDL_IRQ_PRIO_DEFAULT);
    NVIC_EnableIRQ(stcIrqSignConfig.enIRQn);

    DMA_Cmd(DMA_UNIT, ENABLE);
}

static void Slave_Prepare_Transfer(void) {
    // ???????? PH2 (Busy)
    GPIO_ResetPins(READY_PORT, READY_PIN);

    DMA_ChCmd(DMA_UNIT, DMA_TX_CH, DISABLE);
    DMA_ChCmd(DMA_UNIT, DMA_RX_CH, DISABLE);

    DMA_SetSrcAddr(DMA_UNIT, DMA_TX_CH, (uint32_t)(&u8TxBuf[0]));
    DMA_SetTransCount(DMA_UNIT, DMA_TX_CH, EXAMPLE_SPI_BUF_LEN);

    DMA_SetDestAddr(DMA_UNIT, DMA_RX_CH, (uint32_t)(&u8RxBuf[0]));
    DMA_SetTransCount(DMA_UNIT, DMA_RX_CH, EXAMPLE_SPI_BUF_LEN);

    // ????????,??????
    uint32_t u32Err = READ_REG32_BIT(SPI_UNIT->SR, SPI_FLAG_CLR_ALL);
    if (u32Err != 0UL) {
        SPI_ClearStatus(SPI_UNIT, u32Err);
    }

    DMA_ChCmd(DMA_UNIT, DMA_TX_CH, ENABLE);
    DMA_ChCmd(DMA_UNIT, DMA_RX_CH, ENABLE);
    SPI_Cmd(SPI_UNIT, ENABLE);

    // ? ????:?? DMA ?????,?? PH2 ?? BK7258 ????? ?
    GPIO_SetPins(READY_PORT, READY_PIN);
}

static void SystemClock_200MHz_Config(void) {
    stc_clock_pll_init_t stcPLLInit;

    PWC_HighSpeedToHighPerformance();
    EFM_SetWaitCycle(EFM_WAIT_CYCLE5);
    SRAM_SetWaitCycle(SRAM_SRAMH, SRAM_WAIT_CYCLE0, SRAM_WAIT_CYCLE0);
    SRAM_SetWaitCycle((SRAM_SRAM12 | SRAM_SRAM3 | SRAM_SRAMR), SRAM_WAIT_CYCLE1, SRAM_WAIT_CYCLE1);
    GPIO_SetReadWaitCycle(GPIO_RD_WAIT3);

    MODIFY_REG32(CM_CMU->SCFGR,
                 (CMU_SCFGR_HCLKS | CMU_SCFGR_EXCKS | CMU_SCFGR_PCLK0S |
                  CMU_SCFGR_PCLK1S | CMU_SCFGR_PCLK2S | CMU_SCFGR_PCLK3S | CMU_SCFGR_PCLK4S),
                 (CLK_HCLK_DIV1  | CLK_EXCLK_DIV2 | CLK_PCLK0_DIV1 |
                  CLK_PCLK1_DIV2 | CLK_PCLK2_DIV4 | CLK_PCLK3_DIV4 | CLK_PCLK4_DIV4));

    (void)CLK_HrcCmd(ENABLE);
    (void)CLK_PLLStructInit(&stcPLLInit);
    stcPLLInit.u8PLLState = CLK_PLL_ON;
    stcPLLInit.PLLCFGR_f.PLLSRC = CLK_PLL_SRC_HRC;
    stcPLLInit.PLLCFGR_f.PLLM   = 0U;
    stcPLLInit.PLLCFGR_f.PLLN   = 24U;
    stcPLLInit.PLLCFGR_f.PLLP   = 1U;
    (void)CLK_PLLInit(&stcPLLInit);

    while ((CM_CMU->OSCSTBSR & (1UL << 5)) == 0UL) {}
    CLK_SetSysClockSrc(CLK_SYSCLK_SRC_PLL);
    SystemCoreClockUpdate();
}

int32_t main(void) {
    LL_PERIPH_WE(EXAMPLE_PERIPH_WE);
    SystemClock_200MHz_Config();

    // ????????
    for (uint32_t i = 0; i < EXAMPLE_SPI_BUF_LEN; i++) {
        u8TxBuf[i] = (uint8_t)(~i & 0xFF);
    }

    (void)LL_PrintfInit(J4_UART_UNIT, 115200UL, J4_UART_PreInit);
    printf("\r\n========================================\r\n");
    printf("   HC32F460 Solid Handshake Slave Ready \r\n");
    printf("========================================\r\n");

    Handshake_Pin_Init();
    SPI_Config();
    TPH_PowerControl(ENABLE);
    LL_PERIPH_WP(EXAMPLE_PERIPH_WP);

    printf("Slave Listening on SPI1...\r\n");

    for (;;) {
        enRxCompleteFlag = RESET;
        Slave_Prepare_Transfer();

        // ?? Master ????????
        while (RESET == enRxCompleteFlag) {
        }

        SPI_Cmd(SPI_UNIT, DISABLE);
        u32PacketIndex++;

        // ? ???????????,???????????,?????? ?
        for (uint32_t i = 0; i < EXAMPLE_SPI_BUF_LEN; i++) {
            u8TxBuf[i] = (uint8_t)(~u8RxBuf[i]);
        }

        printf("[Packet #%lu] Rx Bytes: %02X %02X %02X %02X ...\r\n",
               u32PacketIndex, u8RxBuf[0], u8RxBuf[1], u8RxBuf[2], u8RxBuf[3]);
    }
}